fx_version 'cerulean'
game 'gta5'

client_scripts {
    'c-radio.lua'
}

server_scripts {
    's-radio.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/*.js',
    'html/*.css',
    'html/img/*.png'
}